export interface User {
  name: string
  email: string
  department: string
  role: "admin" | "user"
}

export interface Ticket {
  id: string;
  title: string;
  description: string;
  category: "hardware" | "software" | "network" | "access";
  priority: "low" | "medium" | "high" | "urgent";
  status: "open" | "in-progress" | "resolved" | "closed";
  requester: string;
  assignee?: string;
  createdAt: Date;
  updatedAt: Date;
  department: string; // ← Añadido
}


export interface TicketStats {
  total: number
  open: number
  inProgress: number
  resolved: number
  closed: number
  urgent: number
  high: number
}
