import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TicketService } from 'src/app/services/ticket.service';
import { Ticket } from 'src/app/models/ticket.model';

@Component({
  selector: 'app-resolve-ticket',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './resolve-ticket.component.html',
  styleUrls: ['./resolve-ticket.component.css'],
})
export class ResolveTicketComponent {
  ticket!: Ticket;
  responses: { author: string; message: string; timestamp: Date }[] = [];
  newResponse = '';

  private route = inject(ActivatedRoute);
  private ticketService = inject(TicketService);

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const allTickets = this.ticketService.getAllTickets();
    this.ticket = allTickets.find((t) => t.id === id)!;
  }

  addResponse() {
    if (!this.newResponse.trim()) return;

    this.responses.push({
      author: 'soporte@empresa.cl',
      message: this.newResponse,
      timestamp: new Date(),
    });
    this.newResponse = '';
  }

  saveChanges() {
    this.ticket.updatedAt = new Date();
    this.ticketService.updateTicket(this.ticket);
    alert('Cambios guardados');
  }
}
